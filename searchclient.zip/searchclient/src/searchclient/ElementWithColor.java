package searchclient;

public class ElementWithColor {
	
		public static enum Color {
			blue, red, green, cyan, magenta, orange, pink, yellow
		};
		
		
	}

