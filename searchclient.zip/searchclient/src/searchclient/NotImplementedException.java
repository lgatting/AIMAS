package searchclient;

public class NotImplementedException extends UnsupportedOperationException {
	private static final long serialVersionUID = 688805131143722526L;
}